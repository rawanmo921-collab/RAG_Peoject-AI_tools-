"""
04_vector_representation.py
=============================
الخطوة 4 من الـ pipeline: تحويل كل chunk لتمثيل رقمي (Vector Embedding).

بيحاول يستخدم SentenceTransformer (all-MiniLM-L6-v2) لو متاح فيه اتصال إنترنت
لتحميل الموديل من huggingface. لو مش متاح، بيرجع لبديل offline (TF-IDF + SVD)
بنفس الواجهة (.encode())، عشان باقي الملفات تشتغل بدون تغيير.

المدخل: data/chunks.csv
المخرج:
    data/embeddings.npy      -> مصفوفة numpy (n_chunks, embedding_dim)
    data/embedding_model.pkl -> الموديل المستخدم محفوظ (لإعادة استخدامه في التوليد وقت الاستعلام)
"""

import os
import pickle

import numpy as np
import pandas as pd

from embedding_utils import get_embedding_model  # موديول مشترك، عشان الـ pickle يتفك من أي ملف

INPUT_PATH = "data/chunks.csv"
EMBEDDINGS_PATH = "data/embeddings.npy"
MODEL_PATH = "data/embedding_model.pkl"


def main():
    print(f"[04] تحميل: {INPUT_PATH}")
    chunks_df = pd.read_csv(INPUT_PATH)
    texts = chunks_df["text"].astype(str).tolist()

    model = get_embedding_model(texts)
    embeddings = model.encode(texts, convert_to_numpy=True, normalize_embeddings=True)
    embeddings = np.asarray(embeddings, dtype=np.float32)

    print(f"[04] شكل مصفوفة الـ embeddings: {embeddings.shape}")

    os.makedirs(os.path.dirname(EMBEDDINGS_PATH), exist_ok=True)
    np.save(EMBEDDINGS_PATH, embeddings)
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)

    print(f"[04] تم حفظ الـ embeddings في: {EMBEDDINGS_PATH}")
    print(f"[04] تم حفظ الموديل في: {MODEL_PATH}")


if __name__ == "__main__":
    main()
