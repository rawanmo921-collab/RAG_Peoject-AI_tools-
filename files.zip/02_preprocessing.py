"""
02_preprocessing.py
====================
الخطوة 2 من الـ pipeline: تنظيف النصوص (Preprocessing).

بياخد المخرجات من 01_documents.py (data/documents_raw.csv) وينضف عمود النص:
  - إزالة الروابط (URLs)
  - إزالة الـ @mentions
  - توحيد المسافات
  - إزالة الصفوف الفاضية بعد التنظيف (لو نص كان مجرد رابط أو منشن مثلاً)
  - إزالة التكرارات (duplicate replies)

المخرج: data/documents_clean.csv بعمود إضافي "text_clean" ونفس الأعمدة الأصلية
(بما فيها author_id اللي هنستخدمه بعدين كـ "brand" في الميتاداتا).
"""

import os
import re
import pandas as pd

INPUT_PATH = "data/documents_raw.csv"
OUTPUT_PATH = "data/documents_clean.csv"


def clean_text(text: str) -> str:
    text = str(text)
    text = re.sub(r"http\S+|www\.\S+", "", text)   # إزالة الروابط
    text = re.sub(r"@\w+", "", text)                # إزالة المنشن
    text = re.sub(r"\s+", " ", text).strip()        # توحيد المسافات
    return text


def preprocess(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["text_clean"] = df["text"].apply(clean_text)

    before = len(df)
    df = df[df["text_clean"].str.len() > 3]          # شيل النصوص الفاضية/التافهة بعد التنظيف
    df = df.drop_duplicates(subset="text_clean")      # شيل التكرارات
    df = df.reset_index(drop=True)
    after = len(df)

    print(f"[02] عدد الصفوف قبل التنظيف: {before}")
    print(f"[02] عدد الصفوف بعد إزالة الفاضي والمكرر: {after}")
    return df


def main():
    print(f"[02] تحميل: {INPUT_PATH}")
    df = pd.read_csv(INPUT_PATH)

    clean_df = preprocess(df)

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    clean_df.to_csv(OUTPUT_PATH, index=False)
    print(f"[02] تم حفظ الداتا المنظفة في: {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
