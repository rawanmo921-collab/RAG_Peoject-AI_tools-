"""
05_create_chroma_store.py
===========================
الخطوة 5 من الـ pipeline: بناء "مخزن المتجهات" (Vector Store) باستخدام Chroma.

بياخد الـ chunks (data/chunks.csv) والـ embeddings الجاهزة (data/embeddings.npy)
من الخطوة اللي فاتت، ويحفظهم في قاعدة بيانات Chroma دائمة (persistent) على القرص،
عشان أي استعلام بعد كده (06_retrieve_context.py أو الـ Streamlit app) يقدر
يفتحها ويبحث فيها من غير ما يعيد حساب الـ embeddings تاني.

كل chunk بيتخزن مع الميتاداتا بتاعته (doc_id, brand) عشان نقدر نفلتر
بالبراند وقت البحث (تخصيص الرد حسب البراند).

المدخل: data/chunks.csv + data/embeddings.npy
المخرج: مجلد chroma_db/ فيه قاعدة بيانات Chroma دائمة، بها collection اسمها
        "support_replies"
"""

import numpy as np
import pandas as pd
import chromadb

CHUNKS_PATH = "data/chunks.csv"
EMBEDDINGS_PATH = "data/embeddings.npy"
CHROMA_DIR = "chroma_db"
COLLECTION_NAME = "support_replies"


def load_chunks_and_embeddings():
    chunks_df = pd.read_csv(CHUNKS_PATH)
    embeddings = np.load(EMBEDDINGS_PATH)
    assert len(chunks_df) == embeddings.shape[0], (
        "عدد الـ chunks لازم يساوي عدد صفوف الـ embeddings"
    )
    return chunks_df, embeddings


def build_chroma_store(chunks_df: pd.DataFrame, embeddings: np.ndarray):
    client = chromadb.PersistentClient(path=CHROMA_DIR)

    # لو الـ collection موجودة من تشغيل سابق، امسحها وابنيها من جديد
    # عشان دايمًا نبني الـ store من أحدث نسخة للداتا
    existing = [c.name for c in client.list_collections()]
    if COLLECTION_NAME in existing:
        client.delete_collection(COLLECTION_NAME)

    # نستخدم embeddings جاهزة من عندنا، فمش محتاجين embedding_function من Chroma
    collection = client.create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"},
    )

    ids = chunks_df["chunk_id"].astype(str).tolist()
    documents = chunks_df["text"].astype(str).tolist()
    metadatas = [
        {"doc_id": int(row["doc_id"]), "brand": str(row["brand"])}
        for _, row in chunks_df.iterrows()
    ]

    collection.add(
        ids=ids,
        embeddings=embeddings.tolist(),
        documents=documents,
        metadatas=metadatas,
    )
    return client, collection


def main():
    print(f"[05] تحميل: {CHUNKS_PATH} و {EMBEDDINGS_PATH}")
    chunks_df, embeddings = load_chunks_and_embeddings()

    print(f"[05] بناء Chroma persistent store في: {CHROMA_DIR}")
    client, collection = build_chroma_store(chunks_df, embeddings)

    print(f"[05] تم إضافة {collection.count()} عنصر إلى الـ collection '{COLLECTION_NAME}'")
    print(f"[05] الـ store محفوظ على القرص، جاهز للاستخدام في 06_retrieve_context.py")


if __name__ == "__main__":
    main()
