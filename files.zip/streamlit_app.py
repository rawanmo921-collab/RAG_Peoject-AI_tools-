"""
streamlit_app.py
==================
واجهة الاستخدام النهائية: مساعد دعم عملاء بـ RAG، مبني فوق كل خطوات
الـ pipeline (01 -> 07).

المتطلبات قبل تشغيل الملف ده (مرة واحدة بس):
    python 01_documents.py
    python 02_preprocessing.py
    python 03_chunking.py
    python 04_vector_representation.py
    python 05_create_chroma_store.py

بعد كده شغّل:
    streamlit run streamlit_app.py

مميزات الواجهة:
  - شات كامل بذاكرة: كل رسائل العميل والردود بتفضل محفوظة طول الجلسة
    (session_state)، وبتتبعت كسياق (history) لكل رد جديد.
  - اختيار برانش/براند اختياري لتخصيص الرد (فلترة الأرشيف على نفس الشركة).
  - عرض شفاف: تحت كل رد، بيتعرض المصادر (chunks) اللي اتبنى عليها الرد،
    ورسالة واضحة لو الرد كان "تحويل للدعم البشري" بسبب عدم تطابق قوي.
"""

import pickle
from importlib import import_module

import pandas as pd
import streamlit as st
import chromadb

# ملفات الـ pipeline أسماؤها بتبدأ برقم، فبنستوردها بـ importlib
retrieve_module = import_module("06_retrieve_context")
prompting_module = import_module("07_prompting")

retrieve_context = retrieve_module.retrieve_context
generate_response = prompting_module.generate_response
evaluate_generated_answer = prompting_module.evaluate_generated_answer

CHROMA_DIR = "chroma_db"
COLLECTION_NAME = "support_replies"
MODEL_PATH = "data/embedding_model.pkl"
CHUNKS_PATH = "data/chunks.csv"


@st.cache_resource
def load_resources():
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    client = chromadb.PersistentClient(path=CHROMA_DIR)
    collection = client.get_collection(COLLECTION_NAME)
    chunks_df = pd.read_csv(CHUNKS_PATH)
    brands = sorted(chunks_df["brand"].dropna().unique().tolist())
    return model, collection, brands


def init_session_state():
    if "history" not in st.session_state:
        st.session_state.history = []  # [{role, content}, ...] لكل الجلسة الحالية
    if "customer_id" not in st.session_state:
        st.session_state.customer_id = "guest"


def main():
    st.set_page_config(page_title="مساعد دعم العملاء (RAG)", page_icon="💬")
    st.title("💬 مساعد دعم العملاء - RAG Assistant")
    st.caption(
        "بيدور في أرشيف ردود الدعم القديمة، يدمج أقرب الردود المشابهة، "
        "ويطلعلك رد واحد مناسب لسؤالك. الشات فاكر كلامك طول الجلسة."
    )

    model, collection, brands = load_resources()
    init_session_state()

    with st.sidebar:
        st.subheader("إعدادات")
        brand_choice = st.selectbox(
            "تخصيص الرد حسب البراند (اختياري)",
            options=["كل البراندات"] + brands,
        )
        brand_filter = None if brand_choice == "كل البراندات" else brand_choice

        k = st.slider("عدد الردود المشابهة المستخدمة (k)", min_value=1, max_value=6, value=3)

        if st.button("🗑️ ابدأ محادثة جديدة (امسح الذاكرة)"):
            st.session_state.history = []
            st.rerun()

    # عرض المحادثة السابقة كاملة (الذاكرة)
    for turn in st.session_state.history:
        role = "user" if turn["role"] == "customer" else "assistant"
        with st.chat_message(role):
            st.write(turn["content"])

    query = st.chat_input("اكتب شكوى أو سؤال العميل هنا...")
    if not query:
        return

    with st.chat_message("user"):
        st.write(query)

    with st.chat_message("assistant"):
        with st.spinner("بدور في أرشيف الردود..."):
            retrieval_result = retrieve_context(
                query, collection, model, k=k, brand=brand_filter
            )
            result = generate_response(
                query, retrieval_result, history=st.session_state.history
            )

        st.write(result["answer"])

        if result["used_fallback"] and not retrieval_result["is_confident"]:
            st.warning("⚠️ عدم تطابق قوي مع الأرشيف - تم تحويل الرد لدعم بشري.")
        elif result["used_fallback"]:
            st.info("ℹ️ تم استخدام رد مدمج مباشرة من الأرشيف (بدون LLM API key).")

        with st.expander("📚 المصادر اللي اتبنى عليها الرد"):
            if retrieval_result["chunks"]:
                for c in retrieval_result["chunks"]:
                    st.write(f"**[{c['brand']}]** (distance={c['distance']:.3f}) — {c['text']}")
            else:
                st.write("لا يوجد مصادر مطابقة.")

    # تحديث الذاكرة (نفس الشيء اللي بيعمله ChatSession.ask، لكن هنا Streamlit
    # بيدير الـ session_state بنفسه فبنضيف الأدوار يدويًا)
    st.session_state.history.append({"role": "customer", "content": query})
    st.session_state.history.append({"role": "assistant", "content": result["answer"]})


if __name__ == "__main__":
    main()
