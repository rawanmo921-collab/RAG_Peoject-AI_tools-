"""
embedding_utils.py
====================
موديول مشترك (helper) بيحتوي على كلاس/دالة تمثيل المتجهات (Embeddings)،
مستخدم من 04_vector_representation.py و 06_retrieve_context.py.

السبب في وجوده كموديول منفصل: ملفات الـ pipeline أسماؤها بتبدأ برقم
(زي 04_vector_representation.py) فمينفعش تعمليها import مباشر في بايثون
(الاسم مش identifier صحيح). فبنحط الكلاس هنا عشان أي ملف يعمل import له
بشكل طبيعي، وعشان الـ pickle يقدر يفك تشفير (unpickle) الموديل المحفوظ
من أي مكان.
"""

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD

try:
    from sentence_transformers import SentenceTransformer
    HAS_SENTENCE_TRANSFORMERS = True
except ImportError:
    HAS_SENTENCE_TRANSFORMERS = False


class SVDEmbeddingModel:
    """بديل offline بنفس واجهة .encode() بتاعة SentenceTransformer.
    بيستخدم TF-IDF + TruncatedSVD (LSA) لما مايكونش فيه اتصال إنترنت
    لتحميل موديل embeddings حقيقي من huggingface."""

    def __init__(self, documents, n_components=30):
        self.vectorizer = TfidfVectorizer()
        doc_tfidf = self.vectorizer.fit_transform(documents)
        n_components = min(n_components, min(doc_tfidf.shape) - 1)
        self.svd = TruncatedSVD(n_components=n_components, random_state=42)
        self.svd.fit(doc_tfidf)

    def encode(self, texts, convert_to_numpy=True, normalize_embeddings=True):
        tfidf_vecs = self.vectorizer.transform(texts)
        dense_vecs = self.svd.transform(tfidf_vecs)
        if normalize_embeddings:
            norms = np.linalg.norm(dense_vecs, axis=1, keepdims=True)
            norms[norms == 0] = 1.0
            dense_vecs = dense_vecs / norms
        return dense_vecs


def get_embedding_model(documents):
    """بيحاول يحمّل SentenceTransformer حقيقي، ولو مش متاح (مفيش إنترنت
    أو المكتبة مش متثبتة) بيرجع لبديل SVDEmbeddingModel offline."""
    if HAS_SENTENCE_TRANSFORMERS:
        try:
            print("[embedding_utils] تحميل موديل SentenceTransformer (all-MiniLM-L6-v2)...")
            return SentenceTransformer("all-MiniLM-L6-v2")
        except Exception as e:
            print(f"[embedding_utils] تعذر تحميل الموديل ({type(e).__name__}). "
                  f"التحول لبديل SVD offline.")
    return SVDEmbeddingModel(documents)
